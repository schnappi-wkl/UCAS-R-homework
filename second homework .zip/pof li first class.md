                                                            **某校四年级女同学身高统计描述**

​                                                                                                  王开来 201948240551008

某校抽取了67名四年级女生进行升高测量，其数据如下：

~~~R
x<-c(126,124,125,126,126,122,120,123,124,127,121,122,128,124,120,127,128,130,
     128,128,128,130,130,130,130,131,131,130,132,131,132,131,130,135,137,139,
     130,129,133,132,130,131,131,131,131,132,132,132,132,131,136,136,135,135,
     135,140,139,138,138,140,141,133,132,134,126,128,135)#某地四年级67名女生身高
~~~
现对该样本数据进行基本的描述性统计分析：

​      **平均数**
$$
平均数
\\\bar{X}=\sum_{i=1}^{n}x_{i}\
$$
~~~R
mean(x)# x=130.5
~~~
  **方差&标准差**
$$
无偏估计方差
\\
\sum_{i=1}^{n}(( x -\bar{x}))^2/n


\\有偏估计 方差
\\
\sum_{i=1}^{n}(( x -\bar{x}))^2/(n-1)

\\无偏估计 标准差
\\
\sqrt{\sum_{i=1}^{n}(( x -\bar{x}))^2/n}

\\有偏估计 方差
\\
\sqrt{\sum_{i=1}^{n}(( x -\bar{x}))^2/(n-1)}
$$
~~~R
var(x)# sd=24.46
sd(x)# sd=4.94
~~~
  **最小值&最大值&中间值&样本范围&分位数&众数**
~~~R
> min(x)#最小值
 120
> max(x)#最大值
 140
> median(x)#中间值
 131
> range(x)#样本范围
 120 140
> quantile(x)#分位数
 0%   25%   50%   75%  100% 
123.0 130.0 133.0 137.5 144.0 
> summary(x)#描述性统计
  0%  25%  50%  75% 100% 
 120  128  131  133  141 
> frq=table(x)#众数
> names(frq)[frq==max(frq)]
130 131

~~~
  **标准误**
$$
{标准误}
标准误
\\S_{\bar{E}}=\frac{s}{\sqrt{n}}
$$
~~~R
se<-function(x)sqrt(var(x)/length(x))
se(x) #se=0.603912
~~~
  **变异系数**
$$
变异系数
\\{CV}=\frac{\sigma  }{\mu }
$$
~~~R
cv<-function(x)sd(x)/mean(x)
cv(x) #cv=0.03787701
~~~
  **正态性检验**
~~~R
shapiro.test(x)

Shapiro-Wilk normality test

data:  x

W = 0.97763, p-value = 0.2686#p>0.05有理由相信数据服从正态分布

~~~
  **偏度**
$$
偏度
\\
\begin{aligned}
&\text { skewness }=\frac{\sum_{i=1}^{N}\left(\chi_{i}-\bar{\chi}\right)^{3}}{(N-1) s^{3}}\\
&\frac{\sum_{i=1}^{n}\left(x_{i}-\bar{x}\right)^{3}}{\sum_{i=1}^{n}\left(x_{i}-\bar{x}\right)^{3 / 2}} \times \frac{(n-1)^{3 / 2}}{n-2} \approx\\
&(\text {mean}-\bmod e) / s \approx 3 \times(\text {mean - median}) / s
\end{aligned}
$$

~~~R
> skewness<-sum((x1-mean(x))^3/sqrt(var(x))^3)/length(x-1)
> skewness #SKU=-0.03558413
~~~
  **峰度**
$$
峰度
\\
kurtosis =\frac{\sum_{i=1}^{N}\left(\chi_{i}-\bar{\chi}\right)^{4}}{(\mathrm{N}-1) \mathrm{s}^{4}}-3
\\
if<0 = Platokurtic 
\\if> 0 = Leptokurtic
    \\ if=0 =Mesokurtic
$$
~~~R
> kurtosis<-sum((x1-mean(x1))^4/var(x1)^2)/length(x1)-3
> kurtosis kur=-0.3587029

~~~
